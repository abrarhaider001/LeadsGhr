import{c as v,j as e,R as N,r as s}from"./assets/client-ZRSI6__3.js";const E=o=>new Date(o).toLocaleString([],{month:"short",day:"numeric",hour:"numeric",minute:"2-digit"}),C=`
  @font-face{font-family:'Instrument Sans';src:url('/fonts/InstrumentSans.ttf') format('truetype');font-weight:400 700;font-display:swap}
  *{box-sizing:border-box}
  html,body{margin:0}
  body{width:360px;background:#fff;color:#190B2D;font:13px/1.4 'Instrument Sans',Arial,sans-serif}
  button,input{font:inherit;color:inherit}
  button{cursor:pointer}
  :focus-visible{outline:2px solid #5B12C9;outline-offset:2px}
  .app{display:flex;flex-direction:column;max-height:560px}
  .top{display:flex;align-items:center;gap:9px;padding:12px 14px;border-bottom:1px solid #ECE8F2}
  .top img{width:22px;height:22px}
  .top strong{font-size:14px;font-weight:600}
  .icons{display:flex;gap:2px;margin-left:auto}
  .icon-btn{display:grid;place-items:center;width:30px;height:30px;padding:0;border:0;border-radius:6px;background:none;color:#675E76}
  .icon-btn:hover:not(:disabled){background:#F4F1F8;color:#190B2D}
  .icon-btn:disabled{cursor:default}
  .icon-btn svg{width:17px;height:17px}
  .icon-btn.spinning svg{animation:spin .8s linear infinite;color:#5B12C9}
  @keyframes spin{to{transform:rotate(360deg)}}
  .body{flex:1;min-height:0;overflow-y:auto;padding:14px}
  .label{margin:0 0 6px;font-size:12px;font-weight:600;color:#3A2E4D}
  .group+.group{margin-top:16px}
  .toggle{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 0;cursor:pointer}
  .toggle+.toggle{border-top:1px solid #ECE8F2}
  .toggle small{display:block;color:#675E76;font-size:12px}
  .switch{position:relative;flex:none;width:34px;height:20px;margin:0;appearance:none;border:0;border-radius:10px;background:#D3CDDC;cursor:pointer}
  .switch:checked{background:#5B12C9}
  .switch:after{content:'';position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;transition:transform .15s}
  .switch:checked:after{transform:translateX(14px)}
  .setup{display:flex;align-items:center;gap:8px;margin:10px 0 0;padding:8px 10px;border-radius:6px;background:#FFF4E5;color:#8A4B00;font-size:12px}
  .setup button{margin-left:auto;padding:0;border:0;background:none;color:#5B12C9;font-weight:600;text-decoration:underline}
  .stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
  .stat{padding:8px 10px;border:1px solid #ECE8F2;border-radius:6px}
  .stat strong{display:block;font-size:17px;font-weight:600}
  .stat span{color:#675E76;font-size:11px}
  .list{margin:0;padding:0;list-style:none}
  .row{display:flex;align-items:center;gap:10px;width:100%;padding:8px 0;border:0;border-top:1px solid #ECE8F2;background:none;text-align:left}
  .row-main{flex:1;min-width:0}
  .subject,.meta{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .subject{font-weight:600}
  .meta{color:#675E76;font-size:12px}
  .count{display:inline-flex;flex:none;align-items:center;gap:4px;color:#675E76;font-size:12px;font-weight:600}
  .ticks{width:20px;height:12px;fill:none;stroke:#A0A4AA;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
  .ticks.sent .tick-first,.ticks.open path{stroke:#5B12C9}
  .empty{margin:8px 0 0;color:#675E76}
  .error{margin:8px 0 0;color:#B42318;font-size:12px}
  .foot{padding:10px 14px;border-top:1px solid #ECE8F2}
  .foot button{width:100%;height:34px;border:1px solid #DFD9EC;border-radius:6px;background:#fff;font-weight:600}
  .foot button:hover{background:#F4F1F8}
`;function S({sent:o,loaded:i}){return e.jsxs("svg",{className:`ticks ${i?"open":o?"sent":""}`,viewBox:"0 0 20 12","aria-hidden":"true",children:[e.jsx("path",{className:"tick-first",d:"M1.5 6.3l3.3 3.3L11.4 3"}),e.jsx("path",{d:"M8.6 8.1l1.5 1.5L16.6 3"})]})}function B(){const[o,i]=s.useState(!0),[m,l]=s.useState(!0),[b,d]=s.useState(!0),[a,p]=s.useState([]),[c,h]=s.useState(!1),[x,r]=s.useState("");s.useEffect(()=>{chrome.storage.local.get(["enabled","notify","endpoint","registrationKey","records"]).then(n=>{i(n.enabled!==!1),l(n.notify!==!1),d(!!(n.endpoint&&n.registrationKey)),p(Array.isArray(n.records)?n.records:[])}).catch(n=>r(String(n)));const t=(n,w)=>{w==="local"&&(n.enabled&&i(n.enabled.newValue!==!1),n.notify&&l(n.notify.newValue!==!1),n.records&&p(Array.isArray(n.records.newValue)?n.records.newValue:[]),(n.endpoint||n.registrationKey)&&chrome.storage.local.get(["endpoint","registrationKey"]).then(u=>d(!!(u.endpoint&&u.registrationKey))))};return chrome.storage.onChanged.addListener(t),()=>chrome.storage.onChanged.removeListener(t)},[]);async function g(t){try{await chrome.storage.local.set(t),r("")}catch(n){r(String(n))}}async function j(){h(!0),r("");try{const t=await chrome.runtime.sendMessage({kind:"tracking:refresh"});if(t?.error)throw new Error(t.error)}catch(t){r(t instanceof Error?t.message:String(t))}finally{h(!1)}}const f=a.filter(t=>t.sent!==!1),k=f.filter(t=>t.loads>0).length,y=a.reduce((t,n)=>t+n.loads,0);return e.jsxs("div",{className:"app",children:[e.jsx("style",{children:C}),e.jsxs("header",{className:"top",children:[e.jsx("img",{src:"/icon.png",alt:""}),e.jsx("strong",{children:"LeadsGhr Tracker"}),e.jsxs("span",{className:"icons",children:[e.jsx("button",{type:"button",className:`icon-btn ${c?"spinning":""}`,"aria-label":c?"Refreshing counts":"Refresh counts",title:"Refresh counts",disabled:c,onClick:()=>{j()},children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[e.jsx("path",{d:"M20 11a8 8 0 1 0-2.3 5.7"}),e.jsx("path",{d:"M20 4v7h-7"})]})}),e.jsx("button",{type:"button",className:"icon-btn","aria-label":"Settings",title:"Settings",onClick:()=>{chrome.runtime.openOptionsPage()},children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[e.jsx("circle",{cx:"12",cy:"12",r:"3"}),e.jsx("path",{d:"M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"})]})})]})]}),e.jsxs("div",{className:"body",children:[e.jsxs("div",{className:"group",children:[e.jsxs("label",{className:"toggle",children:[e.jsxs("span",{children:["Track new emails",e.jsx("small",{children:"Adds a tracking image when you send from Gmail."})]}),e.jsx("input",{className:"switch",type:"checkbox",checked:o,onChange:t=>{i(t.target.checked),g({enabled:t.target.checked})},"aria-label":"Track new emails"})]}),e.jsxs("label",{className:"toggle",children:[e.jsxs("span",{children:["Open notifications",e.jsx("small",{children:"A Chrome notification when an email is opened."})]}),e.jsx("input",{className:"switch",type:"checkbox",checked:m,onChange:t=>{l(t.target.checked),g({notify:t.target.checked})},"aria-label":"Open notifications"})]}),!b&&e.jsxs("p",{className:"setup",children:["Tracking endpoint not set up.",e.jsx("button",{type:"button",onClick:()=>{chrome.runtime.openOptionsPage()},children:"Set up"})]})]}),e.jsxs("div",{className:"group",children:[e.jsx("p",{className:"label",children:"Overview"}),e.jsxs("div",{className:"stats",children:[e.jsxs("div",{className:"stat",children:[e.jsx("strong",{children:f.length}),e.jsx("span",{children:"Tracked"})]}),e.jsxs("div",{className:"stat",children:[e.jsx("strong",{children:k}),e.jsx("span",{children:"Opened"})]}),e.jsxs("div",{className:"stat",children:[e.jsx("strong",{children:y}),e.jsx("span",{children:"Image loads"})]})]})]}),e.jsxs("div",{className:"group",children:[e.jsx("p",{className:"label",children:"Recent emails"}),e.jsx("ul",{className:"list",children:a.slice(0,5).map(t=>e.jsx("li",{children:e.jsxs("div",{className:"row",children:[e.jsxs("span",{className:"row-main",children:[e.jsx("span",{className:"subject",children:t.subject}),e.jsxs("span",{className:"meta",children:[t.recipient," · ",t.sent===!1?"not sent":E(t.sentAt)]})]}),e.jsxs("span",{className:"count",children:[e.jsx(S,{sent:t.sent!==!1,loaded:t.loads>0}),t.loads||""]})]})},t.id))}),a.length===0&&e.jsx("p",{className:"empty",children:"No tracked emails yet. Send an email from Gmail with tracking on."}),x&&e.jsx("p",{className:"error",role:"alert",children:x})]})]})]})}v.createRoot(document.getElementById("root")).render(e.jsx(N.StrictMode,{children:e.jsx(B,{})}));
