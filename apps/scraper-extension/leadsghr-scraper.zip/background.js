import{c as e}from"./chunks/extension-Cucjftaw.js";chrome.runtime.onStartup.addListener(()=>{e("scraper",{force:!0}).catch(()=>{})});
