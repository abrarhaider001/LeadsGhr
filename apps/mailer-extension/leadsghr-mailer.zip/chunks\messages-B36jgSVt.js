const i="sending-tick";function t(n){return!!n&&typeof n=="object"&&"kind"in n&&typeof n.kind=="string"&&String(n.kind).startsWith("sending:")}export{i as S,t as i};
